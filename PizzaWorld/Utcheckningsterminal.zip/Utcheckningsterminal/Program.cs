﻿using System;

namespace Utcheckningsterminal
{
    class Program
    {
        static void Main(string[] args)
        {
            cTerminal terminal = new cTerminal();

            terminal.start();
        }
    }
}
